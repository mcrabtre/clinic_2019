# -*- coding: utf-8 -*-
"""
Created on Sat Mar 30 10:47:30 2019

@author: hokis
"""

import numpy as np
#import pandas as pd
import types
import AccTest
#import queue
#from threading import Thread

#from med_avg import med_avg
#import SVM
#import mcast_send
import aggr_client_v1_3 as aggr_client
import aggr_server
import nodeDetection
import med_avg
#aggr_server(host,num_con,que)

def run(K,tau=0,shuff=0,avc=0):
    
    # node detection
    router_ip = '192.168.0.1'
    host,iplist = nodeDetection.run(router_ip)
    node_dict = {} # determine number of nodes
    n = 0
    for ind in iplist:
        node_dict[ind] = n
        n += 1
    N = n
    if tau ==0:
        tau =N
    multiplier = 10
    d = multiplier * n # number data points per node
    #D = d * N # total number of data points needed
    w = np.zeros(784)
    #w = np.ones(784)
    #filepath = r"train.csv"
    #ww = np.zeros[N,784]
    fnfn = []
    accs = np.zeros(K)

    
    for ind in range (0,K): # aggregator as client, k global iterations 
        # send global update information to nodes
        #data_pts = pd.read_csv(filepath, skiprows=(ind*D), nrows=(D)).values
        #w,fn = NodeSvm.NodeSVM(w,N)
        data = types.SimpleNamespace(w=w,k=ind,host=host,node_dict=node_dict,d=d,tau=n,shuff=shuff)#data_pts=data_pts) #data on nodes
        #datasend = pickle.dumps(data) 
        #print(len(datasend))
        
        #mcast_send.send(data)
        for i in range(0,N):
            aggr_client.client(iplist[i],data)
        
        
        
        # aggregator as server; get ws from nodes 
        result  = aggr_server.aggr_server(host,N)
        ww = result.w
        
        fnfn = np.append(fnfn,result.fn)        

        w = ww
        if avc==1:
            w = med_avg.med(ww)
        elif avc==2:
            w = med_avg.med_avg
        else:
            w = med_avg.mean(ww) 
        data.w = w
        print('averaged')
        accs[ind] = AccTest.AccTest(w)
    print(accs)
    return w,fnfn
 


#use
K = 3
win = np.zeros(784)
stypes = ['None','Random','RoundRobin','SegShift']
avtypes = ['mean','median','med_avg']
for s in range(0,4):
    for i in range(0,2):
        print(stypes[s],avtypes[i])
        w,fn = run(K,avc=i,shuff=s)
print('done')
#print(time.time() - starttime)





