import NodeSVM_v_2 as NodeSvm
import pandaRead
import pandas as pd
from pathlib import Path
import numpy as np
import types
import averager
import time
import AccTest
import Shuffle
import med_avg


start = time.time()
lasttime = start

def run(node_ip,k,tau,win,d,shuff=0,M=1,avc=0):
	print('Running test with N=%i, K=%i, tau=%i, d=%i'%(node_ip,k,tau,d))
	lasttime = time.time()
	N = node_ip
	w = win
	fnfn = []
	D = d*N
	data = pandaRead.pandaRead(D)
	shufftype = ['no','full random','round robin','segment shift']
	avtype = ['Mean','Median','Median Mean']
	print('Using %s shuffling. '%shufftype[shuff],\
	'Processing w using %s.'%avtype[avc])
	for y in range (0,k): # aggregator as client, k global iterations       
		print('Global update %i'%y)
		ww = []
		wn = np.zeros(shape=(N,784))
		fnnode = np.zeros(shape=(N,tau))
		for i in range(N):
			wn[i,:] = w
		for t in range(tau):
			#print('Iteration %i'%t)
			for x in range (0,N): # iterate through the ips of the nodes
				wn[x,:], fnnode[x,t] = NodeSvm.NodeSVM(wn[x,:],data[x*d:(x*d+d),:],tau=1)
			if shuff ==1:
				data = Shuffle.Shuffle(data)
			elif shuff ==2:
				data = Shuffle.rRobin(data,N,M)
			elif shuff==3:
				data = Shuffle.segShift(data,N,M)
		for i in range(N):
			ww = np.append(ww,wn[i,:])
			fnfn = np.append(fnfn,fnnode[i,:])
			
		 # aggregator as server; get ws from nodes        
		# NodeSVM(w, N, tau, D=100, eta=.01, lam=1)

		num_nodes = N# number of machines calculating the loss fn(including aggregator)
		if avc==1:
			w = med_avg.med(wn)
		if avc==2:
			w = med_avg.med_avg(wn)
		else:
			w = med_avg.mean(wn)
		
		acc = AccTest.AccTest(w)
		print('Accuracy is: %.2f'%acc)
	print('Runtime time: %.2f\n\n'%(time.time()-lasttime))

	return w,fnfn
d = 1
M = 1
node_ip = 5
D = node_ip*d*M
k =  2 # number of global updates
tau = 5 # number of local iterations
win = np.zeros(784)
for m in range(0,4):
	for avc in range(0,3):
		w,fn = run(node_ip,k,tau,win,D,shuff=m,M=M, avc=avc)
print('Done')
print('Total System Runtime: %.2f'%(time.time()-start))
