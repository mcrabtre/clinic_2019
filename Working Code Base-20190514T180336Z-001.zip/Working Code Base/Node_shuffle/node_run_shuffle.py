# -*- coding: utf-8 -*-
"""
Created on Tue Mar  5 13:41:40 2019

@author: hokis
"""
import numpy as np
import pandas as pd
import random
import time
import threading
#from threading import Thread
import queue
import matplotlib.pyplot as pt

import SVM_que as SVM
import Read
#import averager
import med_avg
import test1


def to_run(N,d,K,tau,eta,lam,w):
    start = time.time()
    #rnd = random.randint(0, 8)
    for ind in range(K): 
        #eta = 1/(ind+1)
        # get initial data points for node, new set of N*D points for each global iteration
        filepath = r"train.csv"
        D = d*N
        data = pd.read_csv(filepath, skiprows=(ind*D), nrows=(D)).values
        #data = pd.read_csv(filepath, skiprows=(rnd*ind*D), nrows=(D)).values
        #print(ind)

        for jnd in range(tau):
            # shuffle data vectors
            np.random.shuffle(data)
            result = []
            threads = []
            que = queue.Queue()
              
            for knd in range(N): 
                x, y = Read.Read(d, data, weight, jnd*d)
                t = threading.Thread(target=SVM.svm, args=[x,y,w,eta,lam,que])
                t.start()
                threads.append(t)                
                
            for t in threads:           
                t.join()                 
            
            
            while not que.empty():    
                result.append(que.get())
                

#            print(len(result))
            
            # average ws for next local iteration
            resultnp = np.array(result)
            w = med_avg.med_avg(resultnp)
#            w = averager.averager(ww, N)
    # write w to csv file      
#    df = pd.DataFrame(w)
#    df.to_csv('w.csv')

    total = time.time() - start
    print("--- run time: %s seconds ---" %(total))
    return w
    
   
# to run:
weight = 3 # boost
N = 5  # number of nodes
mult = 4
d = mult*N # number of data points
K = 50 # number of global iterations
tau =  N # number local iterations
w = np.zeros(784) # initial w
#win = pd.read_csv(r'w.csv').values
#w = win[:,1]
eta = .01
lam = 1
#w,fn = NodeSVM(w,N,tau,D) 
#data = types.SimpleNamespace(w=w,nodenum=0,tau=tau, k=k) #client(host,data)

w = to_run(N,d,K,tau,eta,lam,w)
    
# test
filepath = r"train.csv"
testsize = 4000
N = random.randint(0, 10)
test_data = pd.read_csv(filepath, skiprows=N*testsize, nrows=(testsize)).values
xtest, ytest = Read.Read(testsize,test_data,weight,0) #pandaread is our function
### Run the test of the vector 
a,pos = test1.testW(w, xtest,ytest,weight)
print("accuracy is: ", a)
print("pos_accuracy is: ", pos)

##Display a color map of W
print("w0 = ",w[0])
pt.figure(1)
w.shape = [28,28]
pt.imshow(w, cmap='seismic')
pt.show()






